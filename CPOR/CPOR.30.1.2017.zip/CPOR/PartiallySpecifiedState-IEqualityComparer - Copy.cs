﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CPOR
{

    class PartiallySpecifiedState_IEqualityComparer2 : IEqualityComparer<PartiallySpecifiedState>
    {
        public bool Equals(PartiallySpecifiedState x, PartiallySpecifiedState y)
        {
            if (x.tmpId == y.tmpId)
            {
                if (x.lActionsWithConditionalEffect.Count == y.lActionsWithConditionalEffect.Count)
                {
                    int i = 0;
                    foreach (Action act in x.lActionsWithConditionalEffect)
                    {
                        if (!y.lActionsWithConditionalEffect.ElementAt(i).Equals(act))
                            return false;
                        i++;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

            bool ans = x.Equals(y);
              if (ans )
                 Console.Write("ff");
            return ans;
        }

        public int GetHashCode(PartiallySpecifiedState x)
        {
            return x.GetHashCode();
        }
    }
}
