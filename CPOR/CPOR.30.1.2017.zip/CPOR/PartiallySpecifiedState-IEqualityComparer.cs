﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CPOR
{

    class PartiallySpecifiedState_IEqualityComparer : IEqualityComparer<PartiallySpecifiedState>
    {
        public bool Equals(PartiallySpecifiedState x, PartiallySpecifiedState y)
        {

            bool ans = x.Equals(y);
            if (ans)
            {
                if (x.regressionFormula != null)
                {
                    for (int i = 0; i < x.regressionFormula.Count; i++)
                    {
                        GroundedPredicate gp = x.regressionFormula.Keys.ElementAt(i);
                        if (x.regressionFormula[gp] == null)
                        {
                            x.regressionFormula[gp] = x.regress(new PredicateFormula(gp), x.countOfActionFromRoot);
                        }
                    }
                }

                if (y.regressionFormula != null)
                {
                    for (int i = 0; i < y.regressionFormula.Count; i++)
                    {
                        GroundedPredicate gp = y.regressionFormula.Keys.ElementAt(i);
                        if (y.regressionFormula[gp] == null)
                        {
                            y.regressionFormula[gp] = y.regress(new PredicateFormula(gp), y.countOfActionFromRoot);
                        }
                    }
                }

                if (x.regressionFormula == null && y.regressionFormula == null)
                    return true;
                if (x.regressionFormula != null && y.regressionFormula == null)
                    return false;
                if (x.regressionFormula == null && y.regressionFormula != null)
                    return false;
                foreach (KeyValuePair<GroundedPredicate, Formula> gf in x.regressionFormula)
                {
                    if (!y.regressionFormula.ContainsKey(gf.Key))
                    {
                        y.regressionFormula.Add(gf.Key, y.regress(new PredicateFormula(gf.Key), y.countOfActionFromRoot));
                    }
                    if (!y.regressionFormula[gf.Key].Equals(gf.Value))
                        return false;
                }

                foreach (KeyValuePair<GroundedPredicate, Formula> gf in y.regressionFormula)
                {
                    if (!x.regressionFormula.ContainsKey(gf.Key))
                    {
                        x.regressionFormula.Add(gf.Key, x.regress(new PredicateFormula(gf.Key), x.countOfActionFromRoot));
                    }
                    if (!x.regressionFormula[gf.Key].Equals(gf.Value))
                        return false;
                }
                return true;
            }
            return ans;
        }

        public int GetHashCode(PartiallySpecifiedState x)
        {
            return x.GetHashCode();
        }
    }
}
